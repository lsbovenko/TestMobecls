<?php
header('Content-Type: text/html; charset=utf-8');

abstract class Coffee{
    protected $price;
    protected $syrup;
    protected $complement;
    protected $prCoffee = array('coffeeSp'=>1, 'milkSp'=>0.3, 'taxSp'=>0.03,
                                'coffeeIt'=>1.5, 'milkIt'=>0.4, 'taxIt'=>0.07,
                                'syrup'=>0.5, 'complement'=>1);
    function __construct($syrup, $complement){
        $this->syrup = $syrup;
        $this->complement = $complement;
        $this->price = $this->getPriceCoffee() + $this->getPriceMilk() + $this->getPriceSyrup() + $this->getPriceComplement();
    }
    abstract function getPriceCoffee();
    abstract function getPriceMilk();
    function getPriceSyrup(){
        if($this->syrup == true)
            return $this->prCoffee['syrup'];
        else
            return 0;
    }
    function getPriceComplement(){
        if($this->complement == true)
            return $this->prCoffee['complement'];
        else
            return 0;
    }
    abstract function getResultPrice();
    abstract function showInfo();
}

class SpCoffee extends Coffee{
    function getPriceCoffee(){
        return $this->prCoffee['coffeeSp'];
    }
    function getPriceMilk(){
        return $this->prCoffee['milkSp'];
    }
    function getResultPrice(){
        return $this->price * ($this->prCoffee['taxSp'] + 1);
    }
    function showInfo(){
        echo "Composition of coffee in Spain:<br>";
        echo "- double coffee<br>";
        echo "- milk<br>";
        if($this->syrup)
            echo "- melon syrup<br>";
        if($this->complement)
            echo "- one chocolate bar<br>";
    }
}

class ItCoffee extends Coffee{
    function getPriceCoffee(){
        return $this->prCoffee['coffeeIt'];
    }
    function getPriceMilk(){
        return $this->prCoffee['milkIt'];
    }
    function getResultPrice(){
        return $this->price * ($this->prCoffee['taxIt'] + 1);
    }
    function showInfo(){
        echo "Composition of coffee in Italy:<br>";
        echo "- one coffee<br>";
        echo "- milk<br>";
        if($this->syrup)
            echo "- coconut syrup<br>";
        if($this->complement)
            echo "- one croissant<br>";
    }
}

class FactCoffee{
    function createCoffee($coffee, $syrup, $complement){
        switch($coffee){
            case "Spain": return new SpCoffee($syrup, $complement);
            case "Italy": return new ItCoffee($syrup, $complement);
            default:
                header('Location: ' . $_SERVER['PHP_SELF']);
                exit;
        }
    }
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $coffee = $_POST['coffee'];
    $syrup = $_POST['syrup'];
    $complement = $_POST['complement'];
    $objCoffee = new FactCoffee();
    $curCoffee = $objCoffee->createCoffee($coffee, $syrup, $complement);
}
?>

<html>
<head>
</head>
<body>
    <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
		<h1 align="center">Coffee</h1><br>
		<select size="1" name="coffee">
            <option disabled>Select country</option>
            <option value="Spain">Spain</option>
            <option value="Italy">Italy</option>
        </select><br><br><br><br>
        <input type="checkbox" name="syrup" value="true">Syrup<br>
        <input type="checkbox" name="complement" value="true">Complement<br>
        <input type="submit" name="submit" value="Made coffee" />
    </form>

<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $curCoffee->showInfo();
        $resPrice = round($curCoffee->getResultPrice(), 2);
        echo "Total price: $resPrice euro";
    }
?>

</body>
</html>